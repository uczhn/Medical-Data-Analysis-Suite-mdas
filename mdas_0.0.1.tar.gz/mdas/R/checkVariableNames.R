#' A checkVariableNames Function
#'
#' This function check if the given parameters' names and the columns' names of the data are the same.
#' @param raw Data in data.frame format.
#' @param parameterName Factor or characters of parameters' names.
#' @author Saisakul Chernbumroong, Henry  Nanji
#' @keywords check variable name
#' @export
# @examples
#' data(iris)
#' checkVariableNames(iris, c("Sepal.Width", "Sepal.Length", "Pepal.Width", "Pepal.Length", "Species"))
checkVariableNames = function(raw, parameterName)
{
  if(all(colnames(raw) == make.names(parameterName)))
  {
    print("The columns' names match the given parameters.")
  }
  else
  {
    cat("The following parameters do not match the columns' name:",
        paste(colnames(raw)[!colnames(raw) == make.names(parameterName)]))
  }
}
