
# mdas

The goal of mdas is to use different functions available to clean and process data, analyse the data using statiscal and machine learning methods.

## Installation

You can install the released version of mdas from [CRAN](https://CRAN.R-project.org) with:

``` r
install.packages("mdas")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(mdas)
## basic example code
```

