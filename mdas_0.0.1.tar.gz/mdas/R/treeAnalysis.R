#' A treeAnalysis Function
#'
#' This function performs data analysis based on Tree algorithms. The function returns tree plot and tree models.
#' @param x independent variable.
#' @param y dependent variable.
#' @param technique tree technique. Examples are c4.5, rf, cart, c5.0.
#' @param nfold the number of folds used in cross-validation.
#' @param nrun the number of repeated runs.
#' @param plot TRUE to produce a tree plot.
#' @param file File
#' @param ... Arguments to be passed for plotting. See ?rpart.plot, ?plot.getTree, ?plot, for further information.
#' @author Saisakul Chernbumroong, Henry  Nanji
#' @return Return a list containing a tree model.
#' @keywords tree analysis
#' @export
# @examples
#' data(iris)
#' result = treeAnalysis(iris[, -5], iris[, 5], technique = "c4.5", nfold = 5, nrun = 10)
treeAnalysis = function(x,y, technique = "c4.5", nfold =5, nrun = 10, plot = T, file = "", ...)
{
  if(technique == "rf")
  {
    #require(randomForest)
    if(requireNamespace("randomForest", quietly = TRUE))
    dat = cbind.data.frame(x,y)
    model = randomForest::randomForest(y~., data = dat, importance=TRUE, mtry = 2, do.trace=100)
    plotHelper(model, file = file, ...)
  }
  else
  {
    model = mlAnalysis(x,y, ml = technique, trfold = nfold, trrun = nrun, nrun = 1, nfold = 1)

    if(plot)
    {
      print(plotHelper(model$models[[1]]$`Run 1`$`Fold 1`$finalModel, file = file, ...))
    }

  }

  return(model)

}
