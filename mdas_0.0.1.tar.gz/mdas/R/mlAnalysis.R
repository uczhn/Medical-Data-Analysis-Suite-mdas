#' A mlAnalysis Function
#'
#' This function performs Machine Learning Analysis. The function returns ML models and confusion matrices for
#' further analysis. For 2-class problem, the model is assessed based on ROC, while accuracy is used in multi-class
#' problem.
#' @param x independent variable.
#' @param y dependent variable.
#' @param ml Machine Leaning algorithm. Examples are rf, c4.5, nb, cart, c5.0, all.
#' @param nfold the number of folds used in cross-validation.
#' @param nrun the number of repeated runs.
#' @param positive an index or a character specifying a positive class
#' @param trrun A numeric value
#' @param trfold  A numeric value
#' @param ... Other options
#' @author Saisakul Chernbumroong, Henry  Nanji
#' @return Return a list of machine learning analysis results.
#'  \item{perf}{A summary of machine learning algorithms performance}
#'  \item{results}{A data.frame containing observations, predictions, class probabilities, algorithms, no. of runs, no. of fold}
#'  \item{models}{A list of machine learning models}
#' @keywords machine learning
#' @export
# @examples
#' data(iris)
#' result = mlAnalysis(iris[, -5], iris[, 5], nfold = 5, nrun = 10)
#' result$models$C4.5
#' result$conf$C4.5
mlAnalysis = function(x,y, ml = "all", nfold = 5, nrun = 10, trfold = 5, trrun = 10, positive = 1, ...)
{
  #require(caret)
  if(requireNamespace("caret", quietly = TRUE))
  ml = tolower(ml)
  #HNN:
  getName <- NULL
  if(is.data.frame(y))
  {
    y = unlist(y)
  }

  lev = levels(y)

  #####Check that selected methods are available
  # available.model = c("rf", "c4.5", "nb", "cart", "c5.0", "all")
  # if(!(all(ml %in% available.model)))
  #   stop("The specified model(s) do not existed. Try rf, c4.5, nb, cart, all")

  #if user select "all" method
  if(ml %in% "all")
  {
    ml = c("rf", "c4.5", "c5.0", "cart", "nb")
  }

  #if use give positive class as an index, change to name
  if(!is.character(positive))
  {
    positive = lev[positive]
  }

  this.ml = getName(ml, TRUE)


  ######Keeping results here
  results = list()
  models = list() #keeping models
  # conf = list() #keeping confusion matrix

  no.level = length(lev)
  isMulti = no.level > 2
  isRegression = no.level == 0
  # tables = list() #keeping tables for comparison
  # tables$overall = vector()
  #
  # if(isMulti)
  # {
  #   tables$sensitivity = vector()
  #   tables$specificity = vector()
  #   tables$precision = vector()
  #   tables$recall = vector()
  #   tables$F1 = vector()
  # }
  # else
  # {
  #   tables$byClass = vector()
  # }


  ######Set up data
  #dat = cbind.data.frame(x,y)

  #####Set up training control. Use ROC in 2-classes problems.
  #for multi class
  if(isRegression)
  {
    trCrl = caret::trainControl(method = "repeatedcv", number = trfold, repeats = trrun)
  }
  else
  {
    if(isMulti)
    {
      trCrl = caret::trainControl(method = "repeatedcv", number = trfold, repeats = trrun,
                           classProbs = TRUE)
    }
    else #for 2-classes
    {
      trCrl = caret::trainControl(method = "repeatedcv", number = trfold, repeats = trrun,
                           classProbs = TRUE, summaryFunction = caret::twoClassSummary)
    }
  }


  #Keeping performance here
  perf = vector()

  dat = cbind.data.frame(x, y)
  for(run in 1:nrun)
  {


    #create folds
    if(is.numeric(y))
    {
      folds = caret::createFolds(1:length(y), k=nfold, returnTrain = F)
    }
    else
    {
      folds = caret::createFolds(y, k=nfold, returnTrain = F)
    }



    for(fold in 1:nfold)
    {
      print(paste("Run", run, " Fold", fold))

      if(nfold == 1 & nrun == 1)
      {
        training = dat
        testing = dat
      }
      else
      {
        #Separate training and testing sets
        training <- dat[-folds[[fold]], ]
        testing <- dat[folds[[fold]], ]
      }




      for(me in this.ml)
      {

        temp_perf = as.data.frame(matrix(NA, nrow(testing), 5+no.level))

        if(isRegression)
        {
          colnames(temp_perf) = c("obs", "pred", "ml", "run", "fold")
        }
        else
        {
          colnames(temp_perf) = c("obs", "pred", lev, "ml", "run", "fold")
        }

        temp_perf$obs = testing[, ncol(testing)]
        temp_perf$run = run
        temp_perf$fold = fold
        temp_perf$ml = getName(me, FALSE)

        # For regression
        if(isRegression)
        {
          models[[getName(me, FALSE)]][[paste("Run", run)]][[paste("Fold", fold)]] <- caret::train(training[, -ncol(training)], training[, ncol(training)],
                                                                                                   method = me, trControl = trCrl, ...)

          temp_perf$pred = stats::predict(models[[getName(me, FALSE)]][[paste("Run", run)]][[paste("Fold", fold)]], testing)
        }
        else  #Set up train control, use ROC in 2-classes problems
        {
          if(isMulti)
          {
            models[[getName(me, FALSE)]][[paste("Run", run)]][[paste("Fold", fold)]] <- caret::train(training[, -ncol(training)], training[, ncol(training)],
                                                                                                     method = me, trControl = trCrl, ...)
            # models[[getName(me, FALSE)]][[paste("Run", run)]][[paste("Fold", fold)]] <- caret::train(as.formula(paste(colnames(training)[ncol(training)],"~.")),
            #                                                                                          data = training, method = me, trControl = trCrl, ...)
          }
          else
          {
            models[[getName(me, FALSE)]][[paste("Run", run)]][[paste("Fold", fold)]] <- caret::train(training[, -ncol(training)], training[, ncol(training)],
                                                                                                     method = me, trControl = trCrl, metric = "ROC",
                                                                                                     ...)
            # models[[getName(me, FALSE)]][[paste("Run", run)]][[paste("Fold", fold)]] <- caret::train(as.formula(paste(colnames(training)[ncol(training)],"~.")),
            #                                                                                          data = training, method = me, trControl = trCrl, metric = "ROC",
            #                 ...)
          }

          temp_perf[, lev] = stats::predict(models[[getName(me, FALSE)]][[paste("Run", run)]][[paste("Fold", fold)]], testing, type = "prob")
          temp_perf$pred = stats::predict(models[[getName(me, FALSE)]][[paste("Run", run)]][[paste("Fold", fold)]], testing)

        }

        perf = rbind.data.frame(perf, temp_perf)


      }



      #Save results
      #conf[[getName(me, FALSE)]] <- caret::confusionMatrix(data = pred, reference = y, positive = positive)
      #tables$overall = cbind(tables$overall, conf[[getName(me, FALSE)]]$overall)

      #####Create table for comparison
      # if(isMulti)
      # {
      #   tables$sensitivity = cbind(tables$sensitivity, conf[[getName(me, FALSE)]]$byClass[, "Sensitivity"])
      #   tables$specificity = cbind(tables$specificity, conf[[getName(me, FALSE)]]$byClass[, "Specificity"])
      #   tables$precision = cbind(tables$precision, conf[[getName(me, FALSE)]]$byClass[, "Precision"])
      #   tables$recall = cbind(tables$recall, conf[[getName(me, FALSE)]]$byClass[, "Recall"])
      #   tables$F1 = cbind(tables$F1, conf[[getName(me, FALSE)]]$byClass[, "F1"])
      # }
      # else
      # {
      #   tables$byClass = cbind(tables$byClass, conf[[getName(me, FALSE)]]$byClass)
      # }

    }
  }

  #Calculate performance here
  results$perf$byClass = vector("numeric")
  results$perf$overall = vector("numeric")

  if(!isMulti)
  {
    results$perf$twoClass = vector("numeric")
  }

  for(me in ml)
  {
    dt = base::subset(perf, ml == me)

    if(isRegression)
    {
      results$perf$overall = cbind(results$perf$overall, caret::defaultSummary(dt))
    }
    else
    {
      results$perf$overall = cbind(results$perf$overall, caret::defaultSummary(dt,lev = lev))
      results$perf$byClass = cbind(results$perf$byClass, caret::multiClassSummary(dt,lev = lev))
      if(!isMulti)
      {
        results$perf$twoClass = cbind(results$perf$twoClass, caret::twoClassSummary(dt,lev = lev))
      }
    }
  }

  if(!isRegression)
  {
    colnames(results$perf$byClass) = ml

    if(!isMulti)
    {
      colnames(results$perf$twoClass) = ml
    }
  }


  colnames(results$perf$overall) = ml



  results$results = perf

  ####Rename comparison table complumn
  # if(isMulti)
  # {
  #
  #   colnames(tables$sensitivity) = ml
  #   colnames(tables$specificity) = ml
  #   colnames(tables$precision) = ml
  #   colnames(tables$recall) = ml
  #   colnames(tables$F1) = ml
  # }
  # else
  # {
  #   colnames(tables$byClass) = ml
  # }


  ###Keeping all in results

  results$models = models
  #results$conf = conf
  #results$tables = tables

  return(results)

}


