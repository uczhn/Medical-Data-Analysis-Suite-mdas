#' A SFS Function
#'
#' This function performs a sequential forward feature selection. Feature is added to the model one by one
#' from the beginning of the list until all features are evaluated. The models' performances are then assessed.
#' @param x data in data.frame.
#' @param y categorical outcomes in factor.
#' @param feaName characters of features.
#' @param method character of a training algorithm.
#' @param nfold the number of folds used in cross-validation.
#' @param nrun the number of repeated runs.
#' @param foldTrain the number of folds used in training.
#' @param runTrain the number of repeated runs used in training.
#' @author Saisakul Chernbumroong, Henry  Nanji
#' @keywords feature selection
#' @return Return a list of Sequential Forward Selection result.
#  \item{results}{A data.frame containing training performances}
#  \item{selectedFeature}{Names of selected variables}
#  \item{no.selectedFeature}{Number of variables selected}
#  \item{trainMethod}{Algorithm used for training}
#' #gather result
#' @export
# @examples
#' data(iris)
#' result = SFS(iris[, -5], iris[, 5], method = "nb", nfold = 5, nrun = 10)
SFS = function(x, y, feaName = colnames(x), method = "nb", nrun = 10, nfold = 5, foldTrain = 5, runTrain = 1)
{
  #require(caret)
  if(requireNamespace("caret", quietly = TRUE))
  #require(fmsb)
  if(requireNamespace("fmsb", quietly = TRUE))

  #make valid names
  y = factor(make.names(y))

  re = vector()
  for(fe in 1:length(feaName))
  {
    acc = c()
    kap = c()

    fea = feaName[1:fe]

    for(r in 1:nrun)
    {
      fold = caret::createFolds(y, k = nfold, returnTrain = T)


      for(f in 1:nfold)
      {
        dat = cbind.data.frame(x,y)
        trainingData = dat[fold[[f]], ]
        testingData = dat[-fold[[f]], ]

        #build model
        isMulti = length(levels(y))>2


        if(isMulti)
        {
          trCrl = caret::trainControl(method = "repeatedcv", number = foldTrain, repeats = runTrain,
                                      classProbs = TRUE)
          if(fe == 1)
          {
            temp.x = data.frame(trainingData[, fea])
            colnames(temp.x) = fea
            mo = caret::train(temp.x, trainingData[, ncol(trainingData)],
                              method = method, trControl = trCrl)
          }
          else
          {
            mo = caret::train(trainingData[, fea], trainingData[, ncol(trainingData)],
                              method = method, trControl = trCrl)
          }


        }
        else #for 2-classes
        {
          trCrl = caret::trainControl(method = "repeatedcv", number = foldTrain, repeats = runTrain,
                               classProbs = TRUE, summaryFunction = caret::twoClassSummary)

          if(fe == 1)
          {
            temp.x = data.frame(trainingData[, fea])
            colnames(temp.x) = fea
            mo = caret::train(temp.x, trainingData[, ncol(trainingData)],
                              method = method, trControl = trCrl, metric = "ROC")
          }
          else
          {
            mo = caret::train(trainingData[, fea], trainingData[, ncol(trainingData)],
                              method = method, trControl = trCrl, metric = "ROC")
          }
        }

        #prediction
        if(fe == 1)
        {
          temp.x = data.frame(testingData[, fea])
          colnames(temp.x) = fea
          pred = stats::predict(mo, temp.x)
        }
        else
        {
          pred = stats::predict(mo, testingData[, fea])
        }


        #performances
        print(cat("Feature", fe, "Run", r, "Fold", f, sep = ", "))
        acc = c(acc, mean(pred == testingData[, ncol(testingData)]))

        ka = NA
        tryCatch({
          ka = fmsb::Kappa.test(pred, testingData[, ncol(testingData)])$Result$estimate
        }, error = function(e){ka = NA})

        kap = c(kap, ka)

      }

    }

    re = rbind.data.frame(re, cbind.data.frame("Variable" = fe,
                                               "Accuracy" = mean(acc),
                                               "Kappa" = mean(kap, na.rm = T),
                                               "AccuracySD" = stats::sd(acc),
                                               "KappaSD" = stats::sd(kap, na.rm = T)))
  }

  #determine which feature set performs best
  sf = mode(c(which(re$Accuracy == max(re$Accuracy)), which(re$Kappa == max(re$Kappa))), method = "all")

  #if there are more than 1 mode, choose the smallest feature set
  if(length(sf) != 1)
  {
    sf = min(sf)
  }

  #if there is no mode, choose the smallest feature set
  if(is.na(sf))
  {
    sf = min(c(which(re$Accuracy == max(re$Accuracy)), which(re$Kappa == max(re$Kappa))))
  }

  #gather result
  result = list()
  result$results = re
  result$selectedFeature = fea[1:sf]
  result$no.selectedFeature = sf
  result$trainMethod = method

  return(result)
}
