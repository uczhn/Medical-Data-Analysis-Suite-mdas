#' A univariateAnalysis Function
#'
#' This function produces univariate plots including histogram with density plot, box plot, q-q plot, and calculate
#' the Shapiro-Wilk statistic for numeric data, and bar chart and pir chart for categorical data.
#' @param dat data in data.frame format
#' @param col.names variable name specify when data only contain 1 variable.
#' @author Saisakul Chernbumroong, Henry  Nanji
#' @return Return plots from univariate analysis.
#' @keywords univariate analysis
#' @export
# @examples
#' data(iris)
#' result = univariateAnalysis(iris)
univariateAnalysis <- function(dat, col.names = NULL)
{
  #require(gridExtra)
  if(requireNamespace("gridExtra", quietly = TRUE))
  #require(grid)
  if(requireNamespace("grid", quietly = TRUE))
  #require(ggplot2)
  if(requireNamespace("ggplot2", quietly = TRUE))
  #require(lattice)
  if(requireNamespace("lattice", quietly = TRUE))
  #
    resids <- shortName <-NULL
  #This function produce qq plot with qq line
  qqplot.data <- function (vec) # argument: vector of numbers
  {
    # following four lines from base R's qqline()
    y <- stats::quantile(vec[!is.na(vec)], c(0.25, 0.75))
    x <- stats::qnorm(c(0.25, 0.75))
    slope <- diff(y)/diff(x)
    int <- y[1L] - slope * x[1L]

    d <- data.frame(resids = vec)

    ggplot2::ggplot(d, ggplot2::aes(sample = resids)) + ggplot2::stat_qq() + ggplot2::geom_abline(slope = slope, intercept = int)
  }



  if(!is.data.frame(dat))
  {
    dat = as.data.frame(dat)
    if(is.null(col.names))
    {
      col.names = "Variable"
    }
    colnames(dat) = make.names(shortName(col.names))
  }

  #shorten names here

  col.name = shortName(colnames(dat))

  for(i in 1:ncol(dat))
  {
    if(is.numeric(dat[, i]))
    {
      # Histogram overlaid with kernel density curve
      his = ggplot2::ggplot(dat, ggplot2::aes_string(x= col.name[i]))
      his = his + ggplot2::geom_histogram(ggplot2::aes(y=stats::density), binwidth = 0.5, colour="black", fill="white")
      his = his + ggplot2::geom_density(alpha=.2, fill="#FF6666")  # Overlay with transparent density plot

      #Box plot
      box = ggplot2::ggplot(dat, ggplot2::aes_string(x = factor(1), y = col.name[i]))
      box = box + ggplot2::geom_boxplot(notch = TRUE)
      box = box + ggplot2::geom_jitter(width = 0.2)
      box = box + ggplot2::labs(x=" ", y = col.name[i])

      #Q-Q Plot
      q = qqplot.data(dat[, i])


      #Test of normality
      # >= 0.05 => normal
      s = stats::shapiro.test(dat[, i])
      t <- grid::textGrob(paste(s$method, col.name[i],
                          paste("Statistic:",round(s$statistic,2)),
                          paste("p-value:",round(s$p.value,2)), sep = "\n"))

      #print all plots!
      gridExtra::grid.arrange(his, box, q, t, ncol=2, top = col.name[i])
    }
    else
    {
      #for categorical data

      #bar chart
      bar <- ggplot2::ggplot(dat, ggplot2::aes_string(col.name[i], fill = col.name[i]))
      bar = bar + ggplot2::geom_bar()

      #pie chart
      label=paste0(round(sort(table(dat[, i]))/sum(table(dat[,i])),2) * 100,"%")
      at <- nrow(dat) - as.numeric(cumsum(sort(table(dat[, i])))-0.5*sort(table(dat[, i])))

      pie <- ggplot2::ggplot(dat, ggplot2::aes_string(x = factor(1), fill = col.name[i])) +
        ggplot2::geom_bar(width = 1)
      pie = pie + ggplot2::coord_polar(theta = "y")
      pie = pie + ggplot2::labs(x=" ", y = " ")
      pie = pie + ggplot2::annotate(geom = "text", y = at, x = 1, label = label)

      #print all plots!
      gridExtra::grid.arrange(bar, pie, ncol=2, top = col.name[i])
    }
  }
}


