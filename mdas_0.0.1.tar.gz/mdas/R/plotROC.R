#' A plotROC Function
#'
#' This function plot a receiver operating characteristic curve.
#' @param classprob data frame of classes' probabilities
#' @param reference vector of true classes
#' @param positive index or character indicating the positive class
#' @param interval smaller value creates finer ROC curve
#' @author Saisakul Chernbumroong, Henry  Nanji
#' @keywords receiver operating characteristic curve
#' @export
# @examples
#' data(iris)
#' model = mlAnalysis(iris[, -5], iris[, 5], ml = "rf")
#' pred = predict(model$models$NB$finalModel, iris[, -5])
#' plotROC(pred$posterior, iris[, 5], "setosa")
plotROC = function(classprob, reference, positive = 1, interval = 0.1)
{
  #require(ggplot2)
  if(requireNamespace("ggplot2", quietly = TRUE))
  stopifnot(sum(colnames(classprob) == levels(reference))==ncol(classprob))

  cutoffs = seq(0, 1, interval)
  roc = vector()
  classes = colnames(classprob)
  for(cutoff in cutoffs)
  {
    if(is.character(positive))
    {
      pred = factor(ifelse(classprob[, positive] > cutoff, classes[which(classes == positive)],
                           classes[-which(classes == positive)]), levels = classes)
      conf = table(stats::relevel(pred, ref = positive), stats::relevel(reference, ref = positive))
      ti = positive
    }
    else
    {
      pred = factor(ifelse(classprob[, positive] > cutoff, classes[positive], classes[-positive]), levels = classes)
      conf = table(stats::relevel(pred, ref = classes[positive]), stats::relevel(reference, ref = classes[positive]))
      ti = colnames(classprob)[positive]
    }

    TPR = conf[1,1]/sum(conf[,1])
    FPR = (sum(conf[1,]) - conf[1,1])/(sum(conf) - sum(conf[,1]))
    roc = rbind.data.frame(roc, cbind.data.frame("TPR" = TPR, "FPR" = FPR))
  }
  rownames(roc) = paste("CutOff", cutoffs, sep = ".")

  gg = ggplot2::ggplot(roc, ggplot2::aes(x=FPR, y=TPR)) + ggplot2::geom_path() +
    ggplot2::geom_abline(intercept = 0, colour = "grey", linetype = 2) + ggplot2::xlim(0,1) + ggplot2::ylim(0,1) +
    ggplot2::ggtitle(paste("ROC curve"), ti)

  graphics::plot(gg)

  return(roc)
}
