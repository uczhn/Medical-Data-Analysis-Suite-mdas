#' A plotHeatmapGroup Function
#'
#' This function plots a heatmap by groups.
#' @param x numerical observations in data.frame format.
#' @param groups groups in factor.
#' @param scale a logical value to indicate if data centering and scaling should be used. It is recommend to use
#' this when producing a heatmap.
#' @param col characters specifying a set of colors used to represent low, mid, and high values, respectively in heatmap.
#' @param stat "mean" to use mean or "median" to use meidan when calculating average values
#' @author Saisakul Chernbumroong, Henry  Nanji
#' @keywords heatmap
#' @export
# @examples
#' data(iris)
#' cl = kmeans(iris[, -5], 3)
#' plotHeatmapGroup(iris[, -5], cl$cluster)
plotHeatmapGroup = function(x, groups, scale = T, col = c("green", "white", "red"), stat = "median")
{
  #require(ggplot2)
  if(requireNamespace("ggplot2", quietly = TRUE))
  #require(reshape2)
  if(requireNamespace("reshape2", quietly = TRUE))

  if(!is.data.frame(x))
  {
    stop("x is not a data.frame")
  }

  if(!all(sapply(x, is.numeric)))
  {
    stop("x contains non-numerical values.")
  }

  if(length(col) != 3)
  {
    stop("You need to specify all three colors for each level.")
  }

  #scale the data.
  if(scale)
  {
    x = scale(x)
  }

  if(!is.factor(groups))
  {
    groups = factor(groups)
  }

  dat = cbind.data.frame(x, "Group" = groups)

  levs = levels(groups)
  no.group = length(levs)

  #
  Group <- value <- variable <-NULL


  #calculate average values for each group
  sub.mean = vector()
  for(g in 1:no.group)
  {
    sub = subset(dat, Group == levs[g], select = -ncol(dat))
    if(tolower(stat) == "mean")
    {
      sub.mean = rbind.data.frame(sub.mean, apply(sub, 2, mean, na.rm = T))
    }
    else if(tolower(stat) == "stats::median")
    {
      sub.mean = rbind.data.frame(sub.mean, apply(sub, 2, stats::median, na.rm = T))
    }

  }

  sub.all = cbind.data.frame(sub.mean, "Group" = levs)
  colnames(sub.all) = colnames(dat)


  #plot heat map
  m = reshape2::melt(sub.all, id.vars = "Group")

  #rotate x label if names are too long.
  if(max(sapply(levs, nchar)) < 6)
  {
    # ggplot(m, aes(variable, Group)) + geom_tile(aes(fill = value), colour = "white") +
    #   scale_fill_gradient2(low = col[1],  high = col[3], mid = col[2], limits = c(-1,1))  +
    #   theme(text = element_text(size=8)) + coord_flip()
    ggplot2::ggplot(m,  ggplot2::aes(variable, Group)) +  ggplot2::geom_tile(ggplot2::aes(fill = value), colour = "white") +
      ggplot2::scale_fill_gradient2(low = col[1],  high = col[3], mid = col[2])  +
      ggplot2::theme(text =  ggplot2::element_text(size=8)) + ggplot2::coord_flip()
  }
  else
  {
    # ggplot(m, aes(variable, Group)) + geom_tile(aes(fill = value), colour = "white") +
    #   scale_fill_gradient2(low = col[1],  high = col[3], mid = col[2], limits = c(-1,1))  +
    #   theme(text = element_text(size=8), axis.text.x = element_text(angle = 90, hjust = 1)) + coord_flip()
    ggplot2::ggplot(m,  ggplot2::aes(variable, Group)) +  ggplot2::geom_tile(ggplot2::aes(fill = value), colour = "white") +
      ggplot2::scale_fill_gradient2(low = col[1],  high = col[3], mid = col[2])  +
      ggplot2::theme(text =  ggplot2::element_text(size=8), axis.text.x =  ggplot2::element_text(angle = 90, hjust = 1)) + ggplot2::coord_flip()
  }


}
