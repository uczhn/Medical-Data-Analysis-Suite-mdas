#' A plotHelper Function
#'
#' This function produces plot from machine Learning models.
#' @param model Machine Learning model.
#' @param file file name to save the plot.
#' @param ... Arguments to be passed for plotting. See ?rpart.plot, ?plot.getTree, ?plot, for further information.
#' @author Saisakul Chernbumroong, Henry  Nanji
#' @keywords plot
#' @export
# @examples
#' data(iris)
#' result = mlAnalysis(iris[, -5], iris[, 5], ml = "c4.5", nfold = 5, nrun = 10)
#' plot(result$models$C4.5$finalmodel)
plotHelper = function(model, file = "", ...)
{
 # require(partykit)
  if(requireNamespace("partykit", quietly = TRUE))
  model.type = class(model)

  if(file != "")
  {

    grDevices::pdf(paste(file,".pdf"), width=40, height=15)
  }

  if(any(model.type == "rpart"))
  {
    #require(rpart.plot)
    if(requireNamespace("rpart.plot", quietly = TRUE))
      rpart.plot::rpart.plot(model, ... = ...)
  }
  else if(any(model.type == "randomForest"))
  #{
    #random forest require model in formula format
    #require(reprtree)
   # if(requireNamespace("reprtree", quietly = TRUE))
    #reprtree:::plot.getTree(model,... =  ...)
  #}
  #else
  {
    graphics::plot(model, ... = ...)
  }

  if(file != "")
  {
    grDevices::dev.off()
  }
}
