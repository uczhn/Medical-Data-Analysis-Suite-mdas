#' A FSAnalysis Function
#'
#' This function performs feature selection based on different algorithms.
#' @param x independent variable.
#' @param y dependent variable.
#' @param fs tree technique. Examples are rf, cfs, rfe, cart, all.
#' @param nfold the number of folds used in cross-validation.
#' @param nrun the number of repeated runs.
#' @param rfefun functions to use with Recursive Feature Elimination. For example, nbFuncs, rfFuncs, for more choices,
#' please see ?caret.
#' @param cfsfun functions to use with Correlation Feature Selection. For example, "nb", "rf", "svmRadial", for more choices,
#' please see ?caret.
#' @param mrmrfun functions to use with Maximum Relevant Minimum Redandant Feature Selection. For example, "nb", "rf", "svmRadial", for more choices,
#' please see ?caret.
#' @param ... Arguments for MRMR please see ?MRMR
#' @author Saisakul Chernbumroong, Henry  Nanji
#' @return Return a list containing results from feature selection.
#' @keywords feature selection
#' @export
#' @references Ding, C. and Peng, H., 2005. Minimum redundancy feature selection
#' from microarray gene expression data. Journal of bioinformatics and computational biology,
#' 3(02), pp.185-205.
# @examples
#' data(iris)
#' result = fsAnalysis(iris[, -5], fs = "all", nfold = 5, nrun = 10)
fsAnalysis = function(x,y, fs = "all", nfold = 5, nrun = 10, rfefun = NULL, cfsfun = NULL,
                      mrmrfun = NULL, ...)
{
  #require(caret)
  if(requireNamespace("caret", quietly = TRUE))

  fs = tolower(fs)
  # :
  MRMR <- SFS <- getName <- NULL
  #if this is categorical/classification
  if(!is.numeric(y))
  {
    y = factor(make.names(y))
  }


  if(fs == "all")
  {
    fs = c("rf", "cfs", "rfe", "cart", "mrmr")
  }

  available.model = c("rf", "cfs", "caret::rfe", "cart", "mrmr")
  if(!all(fs %in% available.model))
    stop("The specified feature selection technique(s) do not existed. Try rf, cfs, caret::rfe, cart, mrmr, all")

  this.fs = fs
  isMulti = length(levels(y)) > 2

  results = list()
  models = list()

  ##Recursive Feature Elimination
  if(any(fs == "caret::rfe"))
  {
    #if user did not specify function, use Naive Bayes
    if(is.null(rfefun))
    {
      rfefun = caret::nbFuncs
    }


    #check if only 1 function is given
    if(class(rfefun[[1]]) == "function")
    {
      control <- caret::rfeControl(functions=rfefun, method="repeatedcv", number=nfold,
                            repeats = nrun, saveDetails = T)
      results$RFE <- caret::rfe(x, y, sizes=c(1:ncol(x)), rfeControl = control)
    }
    else
    {
      for(fu in 1:length(rfefun))
      {
        control <- caret::rfeControl(functions=rfefun[[fu]], method="repeatedcv", number=nfold,
                              repeats = nrun, saveDetails = T)
        results$RFE[[fu]] <- caret::rfe(x, y, sizes=c(1:ncol(x)), rfeControl = control)
      }
    }

  }

  if(any(fs == "cfs"))
  {
   # require(FSelector)
    if(requireNamespace("FSelector", quietly = TRUE))
    selected.list = vector()
    for(r in 1:nrun)
    {
      fold = caret::createFolds(y, k = nfold, returnTrain = T)
      for(f in 1:nfold)
      {
        dat = cbind.data.frame(x,y)

        selected.list = c(selected.list, cfs(formula = y~., data = dat[fold[[f]], ]))
      }
    }
    cfs = as.data.frame(table(selected.list))
    cfs$Freq = cfs$Freq *100 / (nfold*nrun)
    cfs = cfs[order(cfs$Freq, decreasing = T),]
    colnames(cfs) = c("Variable", "Percentage")


    if(is.null(cfsfun))
    {
      cfsfun = "nb"
    }

    results$CFS = SFS(x, y, cfs$Variable, method = cfsfun, nrun = nrun, nfold = nfold, foldTrain = 5, runTrain = 1)
    results$CFS$Ranking = cfs
  }


  ########MRMR
  if(any(fs == "mrmr"))
  {
    selected.list = vector()
    for(r in 1:nrun)
    {
      fold = caret::createFolds(y, k = nfold, returnTrain = T)
      for(f in 1:nfold)
      {
        dat = cbind.data.frame(x,y)

        selected.list = c(selected.list, MRMR(dat[fold[[f]], -ncol(dat)],
                                              dat[fold[[f]], ncol(dat)],
                                              no.of.variable = ncol(dat)-1,
                                              ...))
      }
    }
    mrmr = as.data.frame(table(selected.list))
    mrmr$Freq = mrmr$Freq *100 / (nfold*nrun)
    mrmr = mrmr[order(mrmr$Freq, decreasing = T),]
    colnames(mrmr) = c("Variable", "Percentage")

    if(is.null(mrmrfun))
    {
      mrmrfun = "nb"
    }

    results$MRMR = SFS(x, y, mrmr$Variable, method = mrmrfun, nrun = 10, nfold = 5,
                       foldTrain = 5, runTrain = 1)

    results$MRMR$Ranking = mrmr

  }


  #remove rfe and cfs methods
  this.fs = this.fs[!this.fs %in% c("rfe", "cfs", "mrmr")]

  #####Set up training control. Use ROC in 2-classes problems.
  #for multi class
  if(isMulti)
  {
    trCrl = caret::trainControl(method = "repeatedcv", number = nfold, repeats = nrun,
                         classProbs = TRUE)
  }
  else #for 2-classes
  {
    trCrl = caret::trainControl(method = "repeatedcv", number = nfold, repeats = nrun,
                         classProbs = TRUE, summaryFunction = caret::twoClassSummary)
  }

  #####Change to match methods' names
  this.fs = getName(this.fs, TRUE)

  for(me in this.fs)
  {
    #Set up train control, use ROC in 2-classes problems
    if(isMulti)
    {
      models[[getName(me, FALSE)]] <- caret::train(x, y, method = me, trControl = trCrl)
    }
    else
    {
      models[[getName(me, FALSE)]] <- caret::train(x, y, method = me, trControl = trCrl, metric = "ROC")
    }

    #Perform predictions
    if(me == "rf")
    {
      results$RF = randomForest::importance(models[[getName(me, FALSE)]]$finalModel)
    }
    else if(me == "c5.0")
    {
      results$c5.0 = C50::C5imp(models[[getName(me, FALSE)]]$finalModel)
    }
    else
    {
      results[[getName(me, FALSE)]] = caret::varImp(models[[getName(me, FALSE)]])
    }
  }

  return(results)

}


