#' A clusterAnalysis Function
#'
#' This function perform cluster analysis using various methods. It uses the internal cluster validity
#' indexes to measure the cluster validity. The function returns the cluster analysis results which can
#' be used to determine the optimal number of cluster.
#' @param x a data frame or matrix of data or distance matrix.
#' @param diss TRUE if x is a distance metrix. If FALSE, then x is treated as a matrix of observations by variables.
#' Note that only "pam" and "hierarchy" methods can be used with distance matrix.
#' @param methods clustering methods to use. The function implements 4 clustering algorithms: "kmean" (k-mean),
#' "fuzzy" (Fuzzy c-mean), "pam" (Partitioning Around Medoids), "hierarchy" (Hierarchical Clustering),
#' "hKMean", "hPAM", "hFuzzy" for hierarchical clustering with Kmean, PAM, or Fuzzy c-mean. Use "all",
#' to perform clustering using all methods.
#' @param scale TRUE to scale and center data before clustering
#' @param no.clusters integer numbers of clusters to analyse
#' @param intCri the names of the internal cluster validation index used for validating cluster performances. See
#' getCriteriaNames {clusterCrit} for further details. Use "all" for all available internal cluster indexes.
#' @param repeated an integer number to indicate the number of times the analysis will be repeated.
#' @param distFunc character string specifying the metric to be used for calculating dissimilarities between observations.
#' The currently available options are "euclidean" and "manhattan". Euclidean distances are root sum-of-squares of
#' differences, and manhattan distances are the sum of absolute differences. If x is already a dissimilarity matrix,
#' then this argument will be ignored
#' @param hierMethod character string defining the hierarchical clustering method. See agnes for more details.
#' @param hierConsol TRUE to perform cluster consolidation using k-mean.
#' @param plot TRUE to plot internal cluster criteria results
#' @return Return a list of cluster analysis results
#' \item{clust}{The optimal number of cluster as determined by the internal validation criteria}
#' \item{best}{The optimal number of cluster based on majority vorting}
#' \item{criteria}{The names of internal criteria used for cluster validation}
#' @author Saisakul Chernbumroong, Henry  Nanji
#' @keywords clustering analysis
#' @export
# @examples
#' data(iris)
#' clusterAnalysis(iris[, -5])
clusterAnalysis = function(x, diss = F, methods = "all", scale = T, no.clusters = c(2:10),
                           intCri = "all", repeated = 5, distFunc = "euclidean", hierMethod = "ward",
                           hierConsol = T,  plot = TRUE)
{
  #require(clusterCrit)
  if(requireNamespace("clusterCrit", quietly = TRUE))
  #require(cluster)
  if(requireNamespace("cluster", quietly = TRUE))
  #require(e1071)
  if(requireNamespace("e1071", quietly = TRUE))
  #require(reshape2)
  if(requireNamespace("reshape2", quietly = TRUE))
  #require(ggplot2)
  if(requireNamespace("ggplot2", quietly = TRUE))
  #require(scales)
  if(requireNamespace("scales", quietly = TRUE))

    #
    No.Cluster <- Value <- getCriteriaNames <-hClustCon <- cluster <- NULL
  if(any(no.clusters == 1))
  {
    stop("Number of cluster cannot be 1. The minimum number of cluster is 2.")
  }


  if(any(intCri == "all"))
  {
    intCri = getCriteriaNames(T)
    #remove GDIxx, Log_Det_Ratio, Scott_Symons, S_Dbw as always produced NaN
    intCri = intCri[-c(11:24,26, 33, 36)]
  }

  if(any(methods == "all"))
  {
    methods = c("kmean", "fuzzy", "pam", "hierarchy", "hKMean", "hPAM", "hFuzzy")
  }

  #scale if need be
  if(!diss & scale)
  {
    x = scale(x, center = T, scale = T)
  }

  #keeping results
  clust.result = c()
  best = vector()
  #keeping validation results
  meth = c()

  #Only "pam" and "hierarchy" methods can be used with distance matrix.
  if(diss)
  {
    methods = c("pam", "hierarchy")
  }

  for(me in methods)
  {
    for(re in 1:repeated)
    {
      val = c()
      meth = c(meth, me)

      #run cluster algorithms here
      for(k in no.clusters)
      {
        if(me == "cluster::pam")
        {
          cl = do.call(cluster::pam, c(list(as.matrix(x), diss = diss, k = k, metric = distFunc)))
          cl$cluster = cl$clustering
        }
        else if(me == "cluster::kmean" & !diss)
        {
          cl <- do.call(stats::kmeans, c(list(as.matrix(x), centers = k, nstart = 5)))
        }
        else if(me == "fuzzy" & !diss)
        {
          cl <- do.call(cluster, c(list(as.matrix(x), centers = k, dist = distFunc, method = "cluster::cmeans")))
          if(length(levels(factor(cl$cluster))) != k)
          {
            cl$cluster = NA
          }
        }
        else if(me == "hierarchy")
        {
          cl = hClustCon(x, k = k, hierConsol = FALSE, scale = F, diss = diss)
        }
        else if(me == "hKMean")
        {
          cl = hClustCon(x, k = k, consolMet = "kmean", scale = F, diss = diss)
        }
        else if(me == "hPAM")
        {
          cl = hClustCon(x, k = k, consolMet = "cluster::pam", scale = F, diss = diss)
        }
        else if(me == "hFuzzy")
        {
          cl = hClustCon(x, k = k, consolMet = "fuzzy", scale = F, diss = diss)
        }

        #Calculate internal clustering criteria see clusterCrit for further details
        if(all(is.na(cl$cluster)))
        {
          intIdx = NA
        }
        else
        {
          val = rbind(val, c(k, as.numeric(clusterCrit::intCriteria(as.matrix(x),
                                                       cl$cluster, crit = intCri))))
          colnames(val) = c("Cluster", intCri)
        }


      }



      #Get the best cluster number
      val = rbind(val, c("clust", intCri))

      if(length(intCri) == 1)
      {
        bestClust = val[clusterCrit::bestCriterion(as.numeric(val[1:(nrow(val)-1), 2]), val[nrow(val),2]), "Cluster"]
      }
      else
      {
        bestClust = apply(val[, 2:(length(intCri)+1)], 2, function(x){as.numeric(val[clusterCrit::bestCriterion(as.numeric(x[-length(x)]),
                                                                                                   x[length(x)]), "Cluster"])})
      }


      bestClust.summary = summary(factor(bestClust))

      temp = vector(mode = "integer", length = length(no.clusters) + 1)
      names(temp) = c(as.character(no.clusters), "NaN")
      temp[names(bestClust.summary)] = summary(factor(bestClust))

      #save all results
      clust.result = rbind.data.frame(clust.result, temp)
      colnames(clust.result) = c(as.character(no.clusters), "NA's")


    }



    #find best no. of clust
    sl = clust.result[seq(to=repeated*which(methods == me), by = 1, length.out = repeated),]

    best = rbind.data.frame(best, cbind.data.frame("No.cluster" = names(which.max(apply(sl, 2, FUN = sum))),
                                                   "Method" = me))

    #plot only the last repetition
    if(plot)
    {
      #change to numeric data
      val.temp = val[1:(nrow(val)-1), ]
      val.temp = apply(val.temp, 2, function(x){as.numeric(x)})
      val.temp[, 1] = as.integer(val.temp[, 1])

      #melt
      m = reshape::melt(val.temp, na.rm = T, id = "Cluster")
      #update cluster number
      m$Var1 = val.temp[m$Var1, 1]

      #remove cluster
      m = m[-which(m$Var2 == "Cluster"), ]

      #change melt column names
      colnames(m) = c("No.Cluster", "Criteria", "Value")
      #add highlight
      #Var 1 is number of cluster
      #Var2 is criteria
      #value is value of internal cluster index

      bests = data.frame("Criteria" = colnames(val)[-1],
                         "Value" = apply(val[, -1], 2, function(x){as.numeric(x[clusterCrit::bestCriterion(x = as.numeric(x[-length(x)]), crit = x[length(x)])])}),
                         "No.Cluster" = bestClust)

      #remove any NA
      bests = stats::na.omit(bests)

      #plots
      print(ggplot2::ggplot(m, ggplot2::aes(x=No.Cluster, y=Value)) +
              ggplot2::geom_point() + ggplot2::geom_line() + ggplot2::geom_point(data = bests, ggplot2::aes(x=No.Cluster, y=Value, color = "red"))+
              ggplot2::scale_x_continuous(breaks = function(x) unique(floor(pretty(seq(2, (max(x) + 1) * 1.1))))) +
              ggplot2::scale_y_continuous(breaks = NULL) + ggplot2::facet_wrap( ~ Criteria, scales="free") +
              ggplot2::ggtitle(paste("Internal Cluster Criteria results on", me, collapse = "")))
    }
  }

  #add method name
  clust.result = cbind.data.frame(clust.result, "Method" = meth)




  #add results details
  results = list()
  results$clust = clust.result
  results$best = best
  results$criteria = intCri

  return(results)
}

